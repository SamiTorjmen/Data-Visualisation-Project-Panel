from dashboard_dataviz_panel.plots import table_plotly
from dashboard_dataviz_panel.plots import pie_quali 
from dashboard_dataviz_panel.plots import histogram_quali 
from dashboard_dataviz_panel.plots import boxplot_quali_quanti 
from dashboard_dataviz_panel.plots import scatter_quanti_quanti
from dashboard_dataviz_panel.plots import plotting_target_feature


from dashboard_dataviz_panel.helpers import plotly_to_plt_colors
from dashboard_dataviz_panel.helpers import color_s
from dashboard_dataviz_panel.helpers import categarray
